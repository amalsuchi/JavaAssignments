package com.ey.day5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class Movies {
	private String Mname;
	private String Mlanguage;
	private Date releaseDate;
	private String director;
	private String producer;
	private int duration;
	
	public Movies(String Mname, String Mlanguage , Date releaseDate,String director,String producer,int durartion) {
		this.Mname = Mname;
		this.Mlanguage = Mlanguage;
		this.releaseDate = releaseDate;
		this.director = director;
		this.producer = producer;
		this.duration = duration;
	}
	
	public String getMname() {
		return Mname;
	}
	
	
	public String getLanguage() {
		return Mlanguage;
	}
	
	public String getDirector() {
		return director;
	}
	
	public int getDuration() {
		return duration;
	}
	
	static class LanguageComparator implements Comparator<Movies>{
		public int compare(Movies m1,Movies m2) {
			return m1.getLanguage().compareTo(m2.getLanguage());
		}
	}
	
	static class DirectorComparator implements Comparator<Movies>{
		public int compare(Movies m1, Movies m2) {
			return m1.getDirector().compareTo(m2.getDirector());
		}
	}
}

