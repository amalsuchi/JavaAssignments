package com.ey.day5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class MovieM{
	public List<Movies> movieLists(){
		
		List<Movies> m = new ArrayList<>();
		m.add(new Movies("Drishyam","Malayalam",new Date(),"Jeethu J","JJ",120));
		m.add(new Movies("Drishyam 2","Hindi",new Date(),"AKJ","JJ",130));
		m.add(new Movies("Drishyam 3","Malayalam",new Date(),"Jeethu J","JJ",120));
		
		return m;
	}
	
	public void sortbyLan(List<Movies> mo) {
		Collections.sort(mo, new Movies.LanguageComparator());
	}
	public void sortbydir(List<Movies> mo) {
		Collections.sort(mo, new Movies.DirectorComparator());
	}
	public void sortByDuration(List<Movies> mo) {
		mo.sort(Comparator.comparingInt(Movies::getDuration));
	}
	
	public static void main(String[] args) {
		MovieM manager = new MovieM();
		
		List<Movies> mo =  manager.movieLists();
		
		manager.sortbyLan(mo);
		for(Movies m: mo) {
			System.out.println(m.getMname() + " " + m.getLanguage());
		}
		
		manager.sortbydir(mo);
		for(Movies m: mo) {
			System.out.println(m.getMname() + " " + m.getDirector());
		}
	}
}

