package com.psl.day06.util;

import java.util.LinkedList;

public class Queue<T> {
	private LinkedList<T> elements;
	
	public Queue() {
		elements = new LinkedList<>();
	}
	
	public void enqueue(T element) {
		elements.addLast(element);
	}
	
	public T dequeue() {
		if(isEmpty()) {
			throw new IllegalStateException("Queue us empty");
		}
		return elements.removeFirst();
	}
	
	public T peek() {
		if(isEmpty()) {
			throw new IllegalStateException("Queue us empty");
		}
		return elements.getFirst();
	}
	
	public boolean isEmpty() {
		return elements.isEmpty();
	}
	
	public int size() {
		return elements.size();
	}
	
	public void clear() {
		elements.clear();
	}
	
	public static void main(String[] args) {
		Queue<Integer> intQueue = new Queue<>();
		
		intQueue.enqueue(10);
		intQueue.enqueue(20);
		intQueue.enqueue(30);
		
		while(!intQueue.isEmpty()) {
			System.out.println(intQueue.dequeue());
		}
		
		Queue<Float> fQueue = new Queue<>();
		
		fQueue.enqueue(1.1f);
		fQueue.enqueue(20.2f);
		fQueue.enqueue(30.3f);
		
		
		while(!fQueue.isEmpty()) {
			System.out.println(fQueue.dequeue());
		}
		
		Queue<String> SQueue = new Queue<>();
		
		SQueue.enqueue("AMAL");
		SQueue.enqueue("SIVA");
		SQueue.enqueue("AJ");
		
		
		while(!fQueue.isEmpty()) {
			System.out.println(SQueue.dequeue());
		}
		
		
		
		
	}
	
	
}
