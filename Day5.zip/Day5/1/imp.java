package com.ey.day5;

import java.util.HashSet;

public class imp {

	public static void main(String[] args) {
		
		HashSet<Student> s = new HashSet<>();
		Address one = new Address("manakave","calicut");
		Address two = new Address("manakave","calicut");
		
		Student s1 = new Student(23,"Amal",one);
		Student s2 = new Student(23,"Amal",one);
		s.add(s1);
		s.add(s2);
		
		System.out.println(s.size());
		
	}

}
