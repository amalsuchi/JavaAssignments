package com.ey.day5;

public class Address {
	private String city;
	private String state;
	
	public Address(String city, String state) {
		this.city = city;
		this.state = state;
	}
	public String getcity() {
		return city;
	}
	public void setcity(String city) {
		this.city = city;
	}
	public String getstate() {
		return state;
	}
	public  void SetState(String state) {
		this.state = state;
	}
	
	
	@Override
	public boolean equals(Object o) {
		if(this == o) return true;
		if((o==null) || getClass() != o.getClass()) return false;
		Address address = (Address)o;
		
		return city.equals(address.city) && state.equals(address.state);
		
	}
}
