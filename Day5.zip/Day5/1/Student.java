package com.ey.day5;

public class Student {
	
	Integer age;
	String name;
	Address address;
	
	public Student(Integer age, String name, Address address) {
		this.age = age;
		this.address = address;
		this.name = name;
	}
	
	public Integer getage() {
		return age;
	}
	public String getName() {
		return name;
	}
	public Address getAddress() {
		return address;
	}
	 
	@Override
	public boolean equals(Object o) {
		if( this == o) {
			return true;
		}if(o ==null||getClass() != o.getClass()) {
			
			return false;
		}
		Student s = (Student)o;
		return name.equals(s.name) && age.equals(s.age) && address.equals(s.address);
	}
	public int hashcode(){
		return name.hashCode() + age.hashCode() + address.hashCode();
	}
}
