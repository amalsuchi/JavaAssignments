package com.ey.day5;

import java.util.Comparator;
import java.util.TreeSet;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TreeSet<Employee> em = new TreeSet<>();
		
		em.add(new Employee(1,"Amal","S"));
		em.add(new Employee(2,"Siva","K"));
		em.add(new Employee(3,"AJ","S"));
		
		for(Employee e :em) {
			System.out.println(e);
		}
		
		TreeSet<Employee> embyName = new TreeSet<>(Comparator.comparing(Employee::getfname));
		embyName.addAll(em);
		
		for(Employee e : embyName) {
			System.out.println(e);
		}
		
		

	}

}
