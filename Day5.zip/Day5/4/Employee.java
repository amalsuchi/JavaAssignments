package com.ey.day5;

public class Employee implements Comparable<Employee>{
	private int empid;
	private String fname;
	private String lname;
	
	public Employee(int empid, String fname, String lname) {
		this.empid = empid;
		this.fname = fname;
		this.lname = lname;
	}
	
	public int getid() {
		return empid;
	}
	
	public String getfname() {
		return fname;
	}
	
	public String getlname() {
		return lname;
	}
	
	public int compareTo(Employee other) {
		return Integer.compare(this.empid, other.empid);
	}
	
	public String toString() {
		return empid + " " + fname + " " + lname;
	}
	
     public boolean equals(Object o ) {
		if(o==null) return false;
		if(this == o) return true;
		
		Employee em = (Employee)o;
		return empid == em.empid;
		
	}
	
}
