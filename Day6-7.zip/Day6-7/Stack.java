package com.ey.day6;

public class Stack {
	
	private Contact[] contacts;
	private int top;
	private int maxSize;
	
	public Stack(int maxSize) {
		this.maxSize = maxSize;
		this.contacts =new Contact[maxSize];
		this.top = -1;
	}
	
	public void push(Contact c) throws Exception{
		if(top >= maxSize -1) {
			throw new Exception("Stack is full");
		}
		if(c.isValid()) {
			throw new Exception("contact not valid");
		}
		contacts[++top] = c ;
	}
	
	public Contact pop() throws Exception{
		if(top<0) {
			throw new Exception("Stack is empty");
		}
		return contacts[top--];
	}
	
	public boolean isEmpty() {
		return top == -1;
	}

	public boolean isFull() {
		return top == 1;
	}
	
	
	
	public static void main(String[] args) {
		

	}

}
