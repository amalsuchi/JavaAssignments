package com.ey.day6;

public class ConferenceRoom {
	private boolean available =  true;
	
	public synchronized boolean checkAvailabilty(){
		return available;
	}
	
	public synchronized boolean bookRoom() {
		if(available) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public synchronized void releaseRoom() {
		 available = true;
	}

}
