package com.ey.day6;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;

public class File1 implements Runnable {
	@Override
	public void run() {	
		try {
			byte[] randomdata = new byte[1024];
			new Random().nextBytes(randomdata);
			FileOutputStream of = new FileOutputStream("temp.bmp");
			of.write(randomdata);
			of.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
}

