package com.ey.day6;

public class Manager extends Thread {
	String name;
	ConferenceRoom conferenceRoom;
	
	public Manager(String name,ConferenceRoom c ){
		this.name = name;
		this.conferenceRoom= c;
	}
	
	public void run() {
		while(true) {
			if(conferenceRoom.checkAvailabilty()) {
				if(conferenceRoom.bookRoom()) {
					System.out.println("room has been booked");
					
					try {
						Thread.sleep(2000);
					}catch(InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println("meeting over");
					conferenceRoom.releaseRoom();
					break;
				}
			}else {
				System.out.println(name + " is waiting for the room to become available");
				try {
					Thread.sleep(1000);
				}catch(InterruptedException e){
					e.printStackTrace();
				}
			}
		}
	}

}
