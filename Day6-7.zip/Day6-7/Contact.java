package com.ey.day6;

import java.util.Date;

public class Contact {
	private String firstName;
	private String middleName;
	private String lastName;
	private Date dob;
	private String gender;
	private String mobileNumber;
	
	public Contact() {
		
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstname) {
		this.firstName = firstname;
	}
	
	public String getMiddleName() {
		return middleName;
	}
	
	public void setMiddleName(String middlename) {
		this.middleName = middleName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName ;
	}
	
	public Date getDob() {
		return dob;
	}
	
	public void setDob(Date dob) {
		this.dob = dob;
	}
	
	public String getGender() {
		return gender;
	}
	
	public void setGender(String gender) {
		this.gender = gender ;
	}
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber ;
	}
	
	public boolean isValid() {
		if(firstName == null || middleName == null ||lastName == null) {
			return false;
		}
		return true;
	}
	
}
