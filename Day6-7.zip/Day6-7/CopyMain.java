package com.ey.day6;

public class CopyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File1 f1= new File1();
		File2 f2 = new File2();
		
		Thread f = new Thread(f1);
		Thread g =  new Thread(f2);
		
		f.start();
		g.start();
		
		try {
			f.join();
			g.join();
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Copy completed");
		
		
	}

}
