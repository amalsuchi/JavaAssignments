package com.ey.day6;

public class AverageN {

	public double calavh(int n) {
		if( n<=0) {
			throw new IllegalArgumentException("That is not a natural number");
		}
		
		int sum = n*(n+1)/2;
		
		return (double)sum/n;
		
	}
	public static void main(String[] args) {
		AverageN av = new AverageN();
		
		int n =6;
		
		System.out.println(av.calavh(n));
		
		try {
			n =-1;
			System.out.println(av.calavh(n));
			
		}
		catch(IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
		

	}

}
