package com.ey.day6;

public class BankMain {

	public static void main(String[] args) {
		try {
			BankAccount sa = new BankAccount(101,"amal","Savings",2000);
			sa.deposit(500);
			sa.withdraw(1000);
			sa.withdraw(1000);
			
			BankAccount ca = new BankAccount(101,"aj","Current",6000);
			ca.deposit(1500);
			ca.withdraw(5000);
			ca.withdraw(5000);
		}
		catch(InvalidAmountException|InsufficientFund|LowBalanceException E) {
			System.out.println(E.getMessage());
		}
	}

}
