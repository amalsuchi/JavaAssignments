package com.ey.day6;

public class ConferenceMain {

	public static void main(String[] args) {
		ConferenceRoom c = new ConferenceRoom();
		
		Manager m = new Manager("Manager 1",c);
		Manager m1 = new Manager("Manager 1",c);
		
		m.start();
		m1.start();
		
		try {
			m.join();
			m1.join();
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Booth meeting over`");
				
	}

}
