package com.ey.day6;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class File2 implements Runnable{
	@Override
	public void run() {
		try {
			FileInputStream of = new FileInputStream("temp.bmp");
			FileOutputStream f = new FileOutputStream("image2.bmp");
			
			int data;
			while((data = of.read()) != -1) {
				f.write(data);
			}
			of.close();
			f.close();
		}catch(IOException e) {
			e.printStackTrace();
			
		}
		
		
	}
}
