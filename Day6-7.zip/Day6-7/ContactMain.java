package com.ey.day6;

public class ContactMain {

	public static void main(String[] args) {

		try {
			Stack stack = new Stack(5);
			
			Contact c1 = new Contact();
			
			c1.setFirstName("Amal");
			c1.setMiddleName("S");
			c1.setLastName("S");
			
			stack.push(c1);
			
			Contact c2 = new Contact();
			
			c2.setFirstName("Amasl");
			c2.setMiddleName("Ss");
			c2.setLastName("ssS");
			
			stack.push(c2);
			
			System.out.println(stack.pop().getFirstName());
			System.out.println(stack.pop().getFirstName());
			System.out.println(stack.pop().getFirstName());
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
