package com.ey.day6;

class InvalidAmountException extends Exception{
	public InvalidAmountException(String m) {
		super(m);
	}
}

class InsufficientFund extends Exception{
	public InsufficientFund(String m) {
		super(m);
	}
}

class LowBalanceException extends Exception{
	public LowBalanceException(String m) {
		super(m);
	}
}

public class BankAccount {
	private int accno;
	private String custName;
	private String acctype;
	private float balance;
	
	public BankAccount(int accno, String custName, String acctype, float intialbalance) throws LowBalanceException,InvalidAmountException {
		this.accno = accno;
		this.custName = custName;
		this.acctype = acctype;
		
		if(intialbalance < 0) {
			throw new InvalidAmountException("Intial balance cannot be negative");
		}
		
		if((acctype.equals("Savings") && intialbalance < 1000) ||(acctype.equals("Current") && intialbalance > 5000)) {
			throw new LowBalanceException("inital balance is below th limit");
		}
		this.balance = intialbalance;
		
	
		
	}
	
	public void deposit(float amt) throws InvalidAmountException {
		if(amt <=0) {
			throw new InvalidAmountException("Deposit amount must be positive");
		}
		this.balance += amt;
		
		System.out.println("Deposit successful" + balance);
	}
	
	public void withdraw(float amt) throws InvalidAmountException,InsufficientFund{
		if(amt < 0 ) {
			throw new InsufficientFund("insuffient funds");
		}
		if((acctype.equals("Saving") && (balance - amt)<1000)||(acctype.equals("Current") && (balance - amt)<5000)){
			throw new InsufficientFund("insuffient funds");
			
		}
		this.balance -= amt;
		System.out.println("Balance" + balance);
	}
	
	public float getBalance() {
		return balance;
	}     
}
