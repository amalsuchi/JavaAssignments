package com.ey.day9;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class AuthorServiceImpl implements AuthorService {

	@Override
	public Set<String> getuniqueSurname(List<Author> authorList) {
		return authorList.stream()
				.map(author ->
				author.getsname().toUpperCase()).collect(Collectors.toSet());
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Author> getAuthorsByCity(List<Author> authorList, String city) {
		// TODO Auto-generated method stub
		return authorList.stream().filter(author ->
		author.getcity().equalsIgnoreCase(city)
		).collect(Collectors.toList());
	}

	@Override
	public double femaleAverageAge(List<Author> authorList) {
		// TODO Auto-generated method stub
		return authorList.stream().filter(author ->
		author.getgender().equalsIgnoreCase("female")
		).mapToInt(author -> Period.between(author.getbirthdate(),LocalDate.now()).getYears()).average().orElse(0);
	}

	@Override
	public Long getMobileByAdhar(List<Author> authorList, Long adharCard) {
		// TODO Auto-generated method stub
		return authorList.stream()
				.filter(author ->
				author.getAcard().equals(adharCard)
				).map(Author::getmobile).findFirst().orElse(adharCard);
	}

}
