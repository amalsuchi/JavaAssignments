package com.ey.day9;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public class Author {
	private Long adharCard;
	private String surname;
	private String firstName;
	private String  lastName;
	private LocalDate birthdate;
	private String gender;
	private String city;
	private Long mobile;
	
	public Author(Long ac, String sname ,String fname, String lname, LocalDate birthdate, String gender, String city, Long mobile) {
		this.adharCard = ac;
		this.surname = sname;
		this.firstName = fname;
		this.lastName = lname;
		this.birthdate = birthdate;
		this.gender = gender;
		this.city = city;
		this.mobile = mobile;
	}
	
	public Long getAcard() {
		return adharCard;
	}
	public String getsname() {
		return surname;
	}
	public String getfirstName() {
		return firstName;
	}
	public LocalDate getbirthdate() {
		return birthdate;
	}
	public String getgender() {
		return firstName;
	}
	public String getcity() {
		return city;
	}
	public Long getmobile() {
		return mobile;
	}
	
	
	
	
}


