package com.ey.day9;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

public class AuthorMain {

	public static void main(String[] args) {
		List<Author> authors = Arrays.asList(new Author(12345L,"Amal","S","S",LocalDate.of(2000,12,9),"male","kozhikode",1234567L),
				new Author(12345L,"Amaaal","Saa","Saa",LocalDate.of(2001,12,1),"male","kochi",1213124567L),
				new Author(12345L,"S","P","K",LocalDate.of(2001,7,15),"female","allapy",12341412467L),
				new Author(12345L,"S","P","K",LocalDate.of(2002,7,15),"female","allapy",12341412467L)
				);
		AuthorServiceImpl s = new AuthorServiceImpl();
		Set<String > usurname = s.getuniqueSurname(authors);
		System.out.println(usurname);
		
		List<Author> authorclt = s.getAuthorsByCity(authors,"kozhikode");
		System.out.println(authorclt);
		
		Double avgage = s.femaleAverageAge(authors);
		System.out.println(avgage);
		
		Long mobile = s.getMobileByAdhar(authors,1234567L);
		System.out.println(mobile);
		
		
	}

}
