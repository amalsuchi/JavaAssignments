import React from "react";
import {Link} from 'react-router-dom';

const Home = () =>{
    return(
        <Layout>
            <div>
            <h1>Home Page</h1>
            <nav>
                <ul>
                    <li>
                        <Link to = "/login">Login</Link>
                    </li>
                    <li>
                        <Link to = "/about-us">About Us</Link>
                    </li>
                    <li>
                        <Link to = "/Contact"> Contact</Link>
                    </li>
                </ul>
            </nav>
        </div>
        </Layout>
        
    );
};
export default Home;