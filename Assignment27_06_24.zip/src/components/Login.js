import React, {useState,useEffect} from 'react';

const Login =() => {
    const initialValues = {username: "", email: "", password:""}
    const [formValues,setFormValues] = useState(initialValues);
    const [formErrors,setFormErrors] = useState({});
    const [isSubmit,setIsSubmit] = useState(false);
  
    const handleChange = (e) =>{
      console.log(e.target);
      const{name,value} = e.target;
      setFormValues({...formValues,[name]:value});
      console.log(formValues);
    };
  
    const handleSubmit = (e) => {
      e.preventDefault();
      setFormErrors(validate(formErrors));
      setIsSubmit(true)
    };
  
    useEffect(() =>{
      console.log(formErrors);
      if(Object.keys(formErrors).length ==0 && isSubmit){
        console.log(formValues);
      }
    })
  
    const validate = (values) =>{
      const errors = {}
      if(!values.username){
        errors.username = "username required";
      }
      if(!values.email){
        errors.email = "email required";
      }
      if(!values.password){
        errors.password = "password required";
      }
      return errors;
    }
  
    return(
        <Layout>
             <div className = 'container'>
        <form onSubmit={handleSubmit}>
          <h1>Login Form</h1>
          <div className='ui divider'></div>
          <div className='ui form'>
  
            <div className='field'>
              <label>Username</label>
              <input type='text' name='username' placeholder='Username' value={formValues.username}
              onChange={handleChange}
              />
            </div>
  
            <div className='field'>
              <label>Email</label>
              <input type='email' name='email' placeholder='email' value={formValues.email}
              onChange={handleChange}/>
            </div>
  
            <div className='field'>
              <label>Password</label>
              <input name='password' type='password' placeholder='password' value={formValues.password}
              onChange={handleChange}/>
            </div>
  
            <button className='fieldButton'>Submit</button>
  
          </div>
        </form>
      </div>
        </Layout>
     
    )
  }
  
  export default Login;
  