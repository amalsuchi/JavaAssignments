import React from "react";

const Contact = () => {
    return(
        <Layout>
            <div>
            <h1>Contact Page</h1>
            <p>Contact us at the  +91 1235635289</p>
        </div>
        </Layout>
        
    );
};
export default Contact;