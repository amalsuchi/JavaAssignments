import React from "react";

const AboutUs = () => {
    return(
        <Layout>
            <div>
            <h1> About us Page</h1>
            <p> The About Us page </p>
        </div>
        </Layout>
        
    );
};

export default AboutUs;