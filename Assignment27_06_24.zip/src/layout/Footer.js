import React from "react";

const Footer = () => {
    return(
        <footer>
            <p>&copy; EY AllRights Reserved </p>
        </footer>
    )
}