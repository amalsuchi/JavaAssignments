import React from "react";
import Header from "./Header";
import Footer from './Footer';

const Loayout =({childeren})=> {
    return(
        <div>
            <Header/>
            <main>{childern}</main>
            <Footer/>
        </div>
    );
};
export default useLayoutEffect;