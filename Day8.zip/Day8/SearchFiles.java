package com.ey.day7;

import java.io.File;
import java.util.Scanner;

public class SearchFiles {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ener the  directory to search ");
		
		String directory = sc.nextLine();
		
		System.out.println("Enter the name of file :");
		
		String filename = sc.nextLine();
		
		sc.close();
		
		File dir = new File(directory);
		
		if(!dir.exists() || !dir.isDirectory()) {
			System.out.println("The provided directory does not exist or is not a directory");
			return;
		}
		 
		boolean found = searchForFile(dir,filename);
		
		if(!found) {
			System.out.println("the file is not found");
		}
		
	}
	
	private static boolean searchForFile(File dir, String filename) {
		File[] file = dir.listFiles();
		if(file !=null) {
			for(File f: file) {
				if(f.isDirectory()) {
					if(searchForFile(f,filename)) {
						return true;
					}
					
				}else if(filename.equalsIgnoreCase(f.getName())){
					System.out.println("file found at " + f.getAbsolutePath());
					return true;
				}
			}
		}
		return false;
	}
}


