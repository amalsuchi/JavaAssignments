package com.ey9;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;

public class CallRecordDeserializer {
	@SuppressWarnings("unchecked")

	public static void main(String[] args) {
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("ChargeRecord.ser"))) {
			List<CallDetailRecord> callRecords = (List<CallDetailRecord>)
					in.readObject();
			System.out.println("Call Records:");
			System.out.printf("%-12s %-12s %-10s %-10s%n", "FromNUmber","ToNumber", "Duration", "Charge");
			for (CallDetailRecord record : callRecords) {
				System.out.printf("%-12d %-12d %-10.2f %-10.2f%n", record.getFromNumber(),record.getToNumber(),record.getDuration(),record.getCharge());
			}
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("An error occured during deserialization: "+ e.getMessage());
		}

	}

}
